public class OnboardingProgress {

	private int progressID;
	private int employeeID;
	private int taskDescription;
	private int completionDate;

	public void updateTaskStatus() {
		// TODO - implement OnboardingProgress.updateTaskStatus
		throw new UnsupportedOperationException();
	}

}