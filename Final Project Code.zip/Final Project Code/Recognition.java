public class Recognition {

	private int recognitionID;
	private int associateID;
	private int supervisorID;
	private int message;

}