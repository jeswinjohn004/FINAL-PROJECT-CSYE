import java.util.*;

public class SalesManager extends SalesAssociate {

	/**
	 * Associations
	 */
	private Collection<SalesAssociate> managedEmployees;
	private int managerID;

	public void managePerformanceMetrics() {
		// TODO - implement SalesManager.managePerformanceMetrics
		throw new UnsupportedOperationException();
	}

	public void generatePerformanceReports() {
		// TODO - implement SalesManager.generatePerformanceReports
		throw new UnsupportedOperationException();
	}

	public void manageShiftChanges() {
		// TODO - implement SalesManager.manageShiftChanges
		throw new UnsupportedOperationException();
	}

}