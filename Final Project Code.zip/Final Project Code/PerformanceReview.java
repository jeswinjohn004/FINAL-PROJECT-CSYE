public class PerformanceReview {

	private int reviewID;
	private int associateID;
	private int managerID;
	private int date;

	public void evaluatePerformance() {
		// TODO - implement PerformanceReview.evaluatePerformance
		throw new UnsupportedOperationException();
	}

}