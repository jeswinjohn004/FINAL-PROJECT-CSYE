import java.util.*;

public class HR extends SalesAssociate {

	private Collection<Role> roles;
	private Collection<PayDetails> payDetails;
	private Collection<ImprovementPlan> improvementPlans;
	private Collection<PerformanceMetrics> performanceMetrics;
	private Collection<ShiftChangeRequest> shiftChangeRequests;
	private int associateID;

	public void manageOnboarding() {
		// TODO - implement HR.manageOnboarding
		throw new UnsupportedOperationException();
	}

	public void managePayDetails() {
		// TODO - implement HR.managePayDetails
		throw new UnsupportedOperationException();
	}

	public void generateCompensationReports() {
		// TODO - implement HR.generateCompensationReports
		throw new UnsupportedOperationException();
	}

	public void manageIncrements() {
		// TODO - implement HR.manageIncrements
		throw new UnsupportedOperationException();
	}

}