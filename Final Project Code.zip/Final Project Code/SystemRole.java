public class SystemRole {
}