public class PerformanceMetrics {

	private int metricsID;
	private int associateID;
	private int date;

	public void generatePerformanceReports() {
		// TODO - implement PerformanceMetrics.generatePerformanceReports
		throw new UnsupportedOperationException();
	}

	public void generateComplianceReport() {
		// TODO - implement PerformanceMetrics.generateComplianceReport
		throw new UnsupportedOperationException();
	}

}