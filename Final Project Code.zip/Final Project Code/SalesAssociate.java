public class SalesAssociate {

	private int associateID;
	private int firstName;
	private int lastName;
	private int emailAddress;
	private int password;

	public void viewDocument() {
		// TODO - implement SalesAssociate.viewDocument
		throw new UnsupportedOperationException();
	}

	public void sendRecognition() {
		// TODO - implement SalesAssociate.sendRecognition
		throw new UnsupportedOperationException();
	}

	public void submitPerformanceReview() {
		// TODO - implement SalesAssociate.submitPerformanceReview
		throw new UnsupportedOperationException();
	}

	public void accessOnboardingDocumentation() {
		// TODO - implement SalesAssociate.accessOnboardingDocumentation
		throw new UnsupportedOperationException();
	}

	public void accessOnboardingDocuments() {
		// TODO - implement SalesAssociate.accessOnboardingDocuments
		throw new UnsupportedOperationException();
	}

}