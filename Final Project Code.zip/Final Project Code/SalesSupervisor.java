public class SalesSupervisor extends SalesAssociate {

	private int supervisorID;
	private int manageEmployees;

	public void viewEmployeeOnboardingDocuments() {
		// TODO - implement SalesSupervisor.viewEmployeeOnboardingDocuments
		throw new UnsupportedOperationException();
	}

	public void viewRequests() {
		// TODO - implement SalesSupervisor.viewRequests
		throw new UnsupportedOperationException();
	}

	public void evaluateEmployeePerformance() {
		// TODO - implement SalesSupervisor.evaluateEmployeePerformance
		throw new UnsupportedOperationException();
	}

	public void sendRecognition() {
		// TODO - implement SalesSupervisor.sendRecognition
		throw new UnsupportedOperationException();
	}

}