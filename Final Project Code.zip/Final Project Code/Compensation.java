public class Compensation {

	private int compensationID;
	private int associateID;
	private int salary;

	public void processIncrements() {
		// TODO - implement Compensation.processIncrements
		throw new UnsupportedOperationException();
	}

	public void configureCompensation() {
		// TODO - implement Compensation.configureCompensation
		throw new UnsupportedOperationException();
	}

	public void generateSalaryReports() {
		// TODO - implement Compensation.generateSalaryReports
		throw new UnsupportedOperationException();
	}

}