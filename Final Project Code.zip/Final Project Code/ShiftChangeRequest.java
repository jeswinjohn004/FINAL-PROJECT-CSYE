public class ShiftChangeRequest {

	private int requestID;
	private int associateID;
	private int status;
	private int managerID;

	public void approveShiftChangeRequest() {
		// TODO - implement ShiftChangeRequest.approveShiftChangeRequest
		throw new UnsupportedOperationException();
	}

	public void rejectShiftChangeRequest() {
		// TODO - implement ShiftChangeRequest.rejectShiftChangeRequest
		throw new UnsupportedOperationException();
	}

}