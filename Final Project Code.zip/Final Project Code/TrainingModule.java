public class TrainingModule {

	private int moduleID;
	private int description;
	private int completionDate;

	public void completeModule() {
		// TODO - implement TrainingModule.completeModule
		throw new UnsupportedOperationException();
	}

}