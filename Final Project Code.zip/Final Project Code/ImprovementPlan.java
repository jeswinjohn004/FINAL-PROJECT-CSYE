public class ImprovementPlan {

	private int planID;
	private int associateID;
	private int managerID;
	private int planDate;
	private int planDescription;

	public void managePerformanceImprovementPlan() {
		// TODO - implement ImprovementPlan.managePerformanceImprovementPlan
		throw new UnsupportedOperationException();
	}

}