public class PerformanceEvaluation {

	private int evaluationID;
	private int managerID;
	private int associateID;
	private int date;
	private int rating;
	private int comments;

	public void managePerformanceEvaluation() {
		// TODO - implement PerformanceEvaluation.managePerformanceEvaluation
		throw new UnsupportedOperationException();
	}

}