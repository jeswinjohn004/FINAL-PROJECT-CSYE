public class Role {
}