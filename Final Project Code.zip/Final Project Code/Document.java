public class Document {

	private int documentID;
	private int employeeID;
	private int title;
	private int date;

	public void viewDocument() {
		// TODO - implement Document.viewDocument
		throw new UnsupportedOperationException();
	}

	public void updateDocument() {
		// TODO - implement Document.updateDocument
		throw new UnsupportedOperationException();
	}

	public void deleteDocument() {
		// TODO - implement Document.deleteDocument
		throw new UnsupportedOperationException();
	}

}